## Portfolio
Data Engineer with 5+ years of experience in designing, building, and optimizing robust data pipelines and architectures. Expertise in ETL processes, data warehousing, and big data technologies. Proven ability to collaborate with cross-functional teams to deliver scalable data solutions that drive business growth and efficiency.
 
